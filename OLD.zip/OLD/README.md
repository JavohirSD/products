Required:
PHP version 8.1+
NPM version 8.1+


COMMANDS TO INSTALL PROJECT:

composer update

php artisan migrate

composer require laravel/ui

php artisan ui bootstrap --auth

npm install && npm run dev

npm install && npm run dev
